# Capital Time API

This is a simple Flask-based API that returns the current local time and UTC offset for a given capital city.

## 🔧 How to Run

```bash
pip install -r requirements.txt
python app.py
```

## 🌍 Endpoint

**GET** `/api/time`

### ✅ Headers

- `Authorization: mysecrettoken123`

### 🔍 Query Parameters

- `capital`: Capital city name (e.g., Tokyo, London)

### 📦 Example Request

```bash
curl -X GET "http://<YOUR_EXTERNAL_IP>:5000/api/time?capital=Tokyo" \
     -H "Authorization: mysecrettoken123"
```

### ✅ Example Response

```json
{
  "capital": "Tokyo",
  "local_time": "2025-04-20 22:30:00",
  "utc_offset": "UTC+9"
}
```

## 🔒 Unauthorized Access

```json
{ "error": "Unauthorized access. Valid token required." }
```

## 🚀 Deploying on GCP

1. Create a VM on GCP (Ubuntu)
2. Install Python and Flask
3. Upload this project
4. Run `python3 app.py`
5. Open port 5000 in your firewall
